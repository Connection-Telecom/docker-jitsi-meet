admins = { "focus@auth.cpt.conf.telviva.com" }
plugin_paths = { "/prosody-plugins/", "/prosody-plugins-custom" }
http_default_host = "cpt.conf.telviva.com"












VirtualHost "cpt.conf.telviva.com"

    authentication = "anonymous"

    ssl = {
        key = "/config/certs/cpt.conf.telviva.com.key";
        certificate = "/config/certs/cpt.conf.telviva.com.crt";
    }
    modules_enabled = {
        "bosh";
        "pubsub";
        "ping";
        
        
    }

    c2s_require_encryption = false



VirtualHost "auth.cpt.conf.telviva.com"
    ssl = {
        key = "/config/certs/auth.cpt.conf.telviva.com.key";
        certificate = "/config/certs/auth.cpt.conf.telviva.com.crt";
    }
    authentication = "internal_plain"


VirtualHost "recorder.cpt.conf.telviva.com"
    modules_enabled = {
      "ping";
    }
    authentication = "internal_plain"


Component "internal-muc.cpt.conf.telviva.com" "muc"
    modules_enabled = {
        "ping";
        
    }
    storage = "memory"
    muc_room_cache_size = 1000

Component "muc.cpt.conf.telviva.com" "muc"
    storage = "memory"
    modules_enabled = {
        
        
    }
    muc_room_locking = false
    muc_room_default_public_jids = true

Component "focus.cpt.conf.telviva.com"
    component_secret = "559344174f9221c9feae0a9b12a6793a"

