admins = {
    "focus@auth.cpt.conf.telviva.com",
    "jvb@auth.cpt.conf.telviva.com"
}

plugin_paths = { "/prosody-plugins/", "/prosody-plugins-custom" }
http_default_host = "cpt.conf.telviva.com"













VirtualHost "cpt.conf.telviva.com"

    authentication = "anonymous"

    ssl = {
        key = "/config/certs/cpt.conf.telviva.com.key";
        certificate = "/config/certs/cpt.conf.telviva.com.crt";
    }
    modules_enabled = {
        "bosh";
        "pubsub";
        "ping";
        "speakerstats";
        "conference_duration";
        
        
        
    }

    

    speakerstats_component = "speakerstats.cpt.conf.telviva.com"
    conference_duration_component = "conferenceduration.cpt.conf.telviva.com"

    c2s_require_encryption = false



VirtualHost "auth.cpt.conf.telviva.com"
    ssl = {
        key = "/config/certs/auth.cpt.conf.telviva.com.key";
        certificate = "/config/certs/auth.cpt.conf.telviva.com.crt";
    }
    authentication = "internal_hashed"


VirtualHost "recorder.cpt.conf.telviva.com"
    modules_enabled = {
      "ping";
    }
    authentication = "internal_hashed"


Component "internal-muc.cpt.conf.telviva.com" "muc"
    storage = "memory"
    modules_enabled = {
        "ping";
        
    }
    muc_room_locking = false
    muc_room_default_public_jids = true

Component "muc.cpt.conf.telviva.com" "muc"
    storage = "memory"
    modules_enabled = {
        "muc_meeting_id";
        
        
    }
    muc_room_cache_size = 1000
    muc_room_locking = false
    muc_room_default_public_jids = true

Component "focus.cpt.conf.telviva.com"
    component_secret = "559344174f9221c9feae0a9b12a6793a"

Component "speakerstats.cpt.conf.telviva.com" "speakerstats_component"
    muc_component = "muc.cpt.conf.telviva.com"

Component "conferenceduration.cpt.conf.telviva.com" "conference_duration_component"
    muc_component = "muc.cpt.conf.telviva.com"


